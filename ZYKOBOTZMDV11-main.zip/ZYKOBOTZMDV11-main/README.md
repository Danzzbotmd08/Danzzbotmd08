<p align="center">
    <img src="https://telegra.ph/file/4e4fb84a3d840027150d1.jpg" width="100%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<h1 align="center">Yushino Md V4</h1>

[![BOT WHATSAPP](https://img.shields.io/badge/WhatsApp%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6283838186170) 
[![ONWER](https://img.shields.io/badge/Owner%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6281361281833) 
---------

## TERMUX USER
```bash
$ pkg upgrade && pkg update
$ pkg install git -y
$ pkg install nodejs -y
$ pkg install ffmpeg -y
$ pkg install imagemagick -y
$ git clone https://github.com/Aldi-Ganz-Offc/YushinoMdV4
$ cd YushinoMdV4
$ npm i 
```
If error try using yarn instead of npm, see [here](https://github.com/Aldi-Ganz-Offc/YushinoMdV4#if-npm-install-failed--try--using-yarn-instead-of-npm)
```bash
$ node .
```

#### If npm install failed, try using yarn instead of npm
```bash
$ pkg install yarn -y
$ yarn
```
---------

## TERMUX WITH UBUNTU

```bash
apt update && apt full-upgrade
apt install wget curl git proot-distro
proot-distro install ubuntu
echo "proot-distro login ubuntu" > $PREFIX/bin/ubuntu
ubuntu
```
---------

[ INSTALLING REQUIRED PACKAGES ]

```bash
ubuntu
apt update && apt full-upgrade
apt install wget curl git ffmpeg imagemagick build-essential libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev dbus-x11 ffmpeg2theora ffmpegfs ffmpegthumbnailer ffmpegthumbnailer-dbg ffmpegthumbs libavcodec-dev libavcodec-extra libavcodec-extra58 libavdevice-dev libavdevice58 libavfilter-dev libavfilter-extra libavfilter-extra7 libavformat-dev libavformat58 libavifile-0.7-bin libavifile-0.7-common libavifile-0.7c2 libavresample-dev libavresample4 libavutil-dev libavutil56 libpostproc-dev libpostproc55 graphicsmagick graphicsmagick-dbg graphicsmagick-imagemagick-compat graphicsmagick-libmagick-dev-compat groff imagemagick-6.q16hdri imagemagick-common libchart-gnuplot-perl libgraphics-magick-perl libgraphicsmagick++-q16-12 libgraphicsmagick++1-dev
```

---------

[ INSTALLING NODEJS ]

```bash
ubuntu
curl -fsSL https://deb.nodesource.com/setup_current.x | sudo -E bash -
apt install -y nodejs gcc g++ make
git clone https://github.com/Aldi-Ganz-Offc/YushinoMdV4
cd YushinoMdV4
npm install
npm update
```

---------

## FOR WINDOWS/VPS/RDP USER 💻

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git https://github.com/Aldi-Ganz-Offc/YushinoMdV4
cd YushinoMdV4
npm install
npm update
```

---------

## Run 🏃

```bash
node .
```

---------

#
### 📮 S&K
1. Jangan diperjual belikan Script ini
2. Sebelum pakai jangan lupa kasih star
3. Follow Github !
4. Jangan salah gunakan script ini!

---------


## Thanks To
```bash
𝐀𝐮𝐭𝐡𝐨𝐫 : 𝐴𝑙𝑑𝑖 𝐿𝑒𝑠𝑚𝑎𝑛𝑎 
𝐖𝐚 : 081361281833
𝐛𝐚𝐬𝐞 : 𝑁𝑎𝑟𝑢𝑡𝑜𝑚𝑜
𝐌𝐲 𝐏𝐫𝐨𝐣𝐞𝐜𝐭 : 22 𝐴𝑔𝑢𝑠𝑡𝑢𝑠 2022

⫹❰⫺ 𝐵𝐼𝐺 𝑇𝐻𝐴𝑁𝐾𝑆 𝑇𝑂 ⫹❱⫺
⭝ 𝑨𝒍𝒍𝒂𝒉 𝒀𝒂𝒏𝒈 𝑴𝒂𝒉𝒂 𝑬𝒔𝒂
⭝ 𝑶𝒓𝒂𝒏𝒈 𝑻𝒖𝒂
⭝ 𝑻𝒆𝒎𝒆𝒏 𝑮𝒘
⭝ 𝑴𝒂𝒔𝒕𝒂𝒉 𝑴𝒂𝒔𝒕𝒂𝒉
⫹⫺ 𝑇𝒉𝑒 𝑁𝑎𝑚𝑒 𝑇𝒉𝑎𝑡 𝐻𝑒𝑙𝑝𝑒𝑑 𝑀𝑒 ⫹⫺
⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔⸔
⭝ 𝑨𝒅𝒊𝒘𝒂𝒋𝒊𝒔𝒉𝒊𝒏𝒈
⭝ 𝑵𝒂𝒓𝒖𝒕𝒐𝒎𝒐
⭝ 𝑹𝒊𝒔𝒎𝒂𝑩𝒐𝒕𝒛 𝑶𝒇𝒇𝒄
⭝ 𝑱𝒂𝒓𝒐𝒕 𝑶𝒇𝒇𝒄
⭝ 𝑯𝒚𝒛𝒆𝒓
⭝ 𝑫𝒆𝒇𝒇𝒓𝒊
⭝ 𝑬𝒍𝒂𝒊𝒏𝒂
⭝ 𝑲𝒂𝒏𝒏𝒂𝑪𝒉𝒂𝒏
⭝ 𝑪𝒉𝒓𝒊𝒔𝒕𝒊𝒂𝒏 𝑰𝒅
⭝ 𝑨𝒊𝒏𝒆
⭝ 𝑾𝒉 𝑴𝒐𝒅𝒔 𝑫𝒆𝒗
⭝ 𝑨𝒓𝒊𝒇𝒇𝒃
⭝ 𝑰𝒍𝒎𝒂𝒏
⭝ 𝑨𝒎𝒊𝒓𝒖𝒍
⭝ 𝑰𝒔𝒕𝒊𝒌𝒎𝒂𝒍
⭝ 𝑭𝒛𝒐𝒏𝒆
⭝ 𝑭𝒂𝑱𝒂𝒓
⭝ 𝑨𝒓𝒖𝒍𝒍 𝑶𝒇𝒄
⭝ 𝒁𝒆𝒆𝒐𝒏𝒆 𝑶𝒇𝒄
⭝ 𝑹𝒂𝒎𝒍𝑎𝑛
⭝ 𝑮𝒆𝒎𝒑𝒚𝑻𝒐𝒏
⭝ 𝑺𝒂𝒊𝒑𝒖𝒍 𝑨𝒏𝒖𝒓
```

